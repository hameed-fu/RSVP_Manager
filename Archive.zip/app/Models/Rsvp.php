<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Rsvp extends Model
{
    protected $fillable = [
        'name',
        'address',
        'phone',
        'email',
        'guests_count',
        'message',
        'status',
        'payment_type',
        'school_choice',
        'ticket_code'
    ];

    protected $casts = [
        'guests_count' => 'integer',
    ];

    public function payment()
    {
        return $this->hasOne(Payment::class);
    }
}
